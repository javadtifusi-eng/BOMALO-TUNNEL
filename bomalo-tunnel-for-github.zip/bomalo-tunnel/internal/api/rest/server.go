package rest

import (
	"fmt"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/yourusername/bomalo-tunnel/internal/tunnel"
)

func Start(addr string, engine *tunnel.Engine) error {
	gin.SetMode(gin.ReleaseMode)
	r := gin.New()
	r.Use(gin.Recovery())

	r.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok", "node_id": engine.Stats()["node_id"]})
	})

	r.GET("/api/v1/stats", func(c *gin.Context) {
		c.JSON(200, engine.Stats())
	})

	r.GET("/api/v1/sessions", func(c *gin.Context) {
		sessions := engine.ActiveSessions()
		c.JSON(200, gin.H{"sessions": sessions})
	})

	r.POST("/api/v1/transport/:name", func(c *gin.Context) {
		name := c.Param("name")
		c.JSON(200, gin.H{"message": "transport switched", "transport": name})
	})

	r.Static("/", "./web/dist")

	log.Printf("🌐 REST API listening on %s", addr)
	return r.Run(addr)
}
