package grpc

import (
	"context"
	"fmt"
	"log"
	"net"

	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	emptypb "google.golang.org/protobuf/types/known/emptypb"
	"github.com/yourusername/bomalo-tunnel/internal/tunnel"
)

type Server struct {
	engine *tunnel.Engine
	grpc   *grpc.Server
}

func New(engine *tunnel.Engine) *Server {
	return &Server{engine: engine}
}

func (s *Server) Start(addr string) error {
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return fmt.Errorf("grpc listen: %w", err)
	}

	s.grpc = grpc.NewServer()
	reflection.Register(s.grpc)

	log.Printf("🚀 gRPC server listening on %s", addr)
	return s.grpc.Serve(ln)
}

func (s *Server) Stop() {
	if s.grpc != nil {
		s.grpc.GracefulStop()
	}
}

func (s *Server) GetStats(ctx context.Context, req *emptypb.Empty) (*emptypb.Empty, error) {
	return &emptypb.Empty{}, nil
}
