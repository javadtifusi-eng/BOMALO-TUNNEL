package i18n

import "os"

var lang = "en"

func init() {
	if v := os.Getenv("BOMALO_LANG"); v == "fa" {
		lang = "fa"
	}
}

func SetLanguage(l string) {
	if l == "fa" || l == "en" {
		lang = l
	}
}

func T(key string) string {
	if lang == "fa" {
		if v, ok := fa[key]; ok {
			return v
		}
	}
	if v, ok := en[key]; ok {
		return v
	}
	return key
}

var en = map[string]string{
	"welcome":           "Welcome to Bomalo Tunnel",
	"setup_iran":        "Setup Iran Server (Entry Point)",
	"setup_kharej":      "Setup Kharej Server (Exit Node)",
	"test_servers":      "Test Both Servers Before Install",
	"manage":            "Manage Tunnels",
	"backup":            "Backup & Restore",
	"web_panel":         "Web Panel",
	"optimize":          "Optimize System",
	"update":            "Update",
	"uninstall":         "Uninstall",
	"exit":              "Exit",
	"select_option":     "Select an option: ",
	"auto_ip_detected":  "Auto-detected IP: %s",
	"enter_iran_ip":     "Enter Iran Server IP: ",
	"enter_kharej_ip":   "Enter Kharej Server IP: ",
	"testing_dns":       "Testing Google DNS (8.8.8.8)...",
	"dns_ok":            "DNS test passed",
	"dns_fail":          "DNS test failed",
	"testing_i2k":       "Testing Iran → Kharej connection...",
	"testing_k2i":       "Testing Kharej → Iran connection...",
	"test_pass":         "Connection test PASSED",
	"test_fail":         "Connection test FAILED",
	"install_blocked":   "Installation blocked: connection test failed. Fix network issues first.",
	"ssl_prompt":        "Do you have a domain for SSL? (y/n): ",
	"enter_domain":      "Enter domain (e.g. tunnel.example.com): ",
	"ssl_ip_fallback":   "No domain provided. Falling back to IP-based setup.",
	"certbot_install":   "Installing Certbot and obtaining SSL certificate...",
	"using_ip":          "Using IP address for tunnel (no SSL)",
	"install_success":   "Installation completed successfully!",
	"token_generated":   "Generated secure token: %s",
	"copy_token":        "COPY THIS TOKEN to Kharej server during setup",
	"port_forward":      "Enter ports to forward (comma-separated, e.g. 443,8080): ",
	"role_iran":         "Role: IRAN (Entry Point)",
	"role_kharej":       "Role: KHAREJ (Exit Node)",
	"health_check":      "Running health check...",
	"link_test":         "Running link quality test...",
	"recommend_quic":    "Recommended: QUIC (low latency, high score)",
	"recommend_tcp":     "Recommended: TCP (stable, fallback)",
	"recommend_wg":      "Recommended: WireGuard (stealth mode)",
}

var fa = map[string]string{
	"welcome":           "به Bomalo Tunnel خوش آمدید",
	"setup_iran":        "راه‌اندازی سرور ایران (نقطه ورود)",
	"setup_kharej":      "راه‌اندازی سرور خارج (نقطه خروج)",
	"test_servers":      "تست هر دو سرور قبل از نصب",
	"manage":            "مدیریت تانل‌ها",
	"backup":            "پشتیبان‌گیری و بازیابی",
	"web_panel":         "پنل وب",
	"optimize":          "بهینه‌سازی سیستم",
	"update":            "بروزرسانی",
	"uninstall":         "حذف نصب",
	"exit":              "خروج",
	"select_option":     "یک گزینه انتخاب کنید: ",
	"auto_ip_detected":  "IP شناسایی‌شده: %s",
	"enter_iran_ip":     "IP سرور ایران را وارد کنید: ",
	"enter_kharej_ip":   "IP سرور خارج را وارد کنید: ",
	"testing_dns":       "در حال تست DNS گوگل (8.8.8.8)...",
	"dns_ok":            "تست DNS موفق بود",
	"dns_fail":          "تست DNS ناموفق بود",
	"testing_i2k":       "در حال تست اتصال ایران → خارج...",
	"testing_k2i":       "در حال تست اتصال خارج → ایران...",
	"test_pass":         "تست اتصال موفق بود",
	"test_fail":         "تست اتصال ناموفق بود",
	"install_blocked":   "نصب مسدود شد: تست اتصال ناموفق بود. ابتدا مشکلات شبکه را برطرف کنید.",
	"ssl_prompt":        "آیا دامنه برای SSL دارید؟ (بله/خیر): ",
	"enter_domain":      "دامنه را وارد کنید (مثال: tunnel.example.com): ",
	"ssl_ip_fallback":   "دامنه وارد نشد. استفاده از IP.",
	"certbot_install":   "نصب Certbot و دریافت گواهی SSL...",
	"using_ip":          "استفاده از آدرس IP برای تانل (بدون SSL)",
	"install_success":   "نصب با موفقیت انجام شد!",
	"token_generated":   "توکن امن تولید شد: %s",
	"copy_token":        "این توکن را در سرور خارج کپی کنید",
	"port_forward":      "پورت‌های فوروارد را وارد کنید (با کاما جدا کنید، مثال: 443,8080): ",
	"role_iran":         "نقش: ایران (نقطه ورود)",
	"role_kharej":       "نقش: خارج (نقطه خروج)",
	"health_check":      "در حال بررسی سلامت...",
	"link_test":         "در حال تست کیفیت لینک...",
	"recommend_quic":    "پیشنهاد: QUIC (تاخیر کم، امتیاز بالا)",
	"recommend_tcp":     "پیشنهاد: TCP (پایدار، fallback)",
	"recommend_wg":      "پیشنهاد: WireGuard (حالت مخفی)",
}
