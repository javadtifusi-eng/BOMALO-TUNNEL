package config

import (
	"fmt"
	"os"

	"github.com/spf13/viper"
)

type Config struct {
	Role          string   `mapstructure:"role"`
	NodeID        string   `mapstructure:"node_id"`
	Token         string   `mapstructure:"token"`
	IranAddr      string   `mapstructure:"iran_addr"`
	TunnelPort    int      `mapstructure:"tunnel_port"`
	Transports    []string `mapstructure:"transports"`
	AutoTransport bool     `mapstructure:"auto_transport"`
	Ports         []int    `mapstructure:"ports"`
	GRPCAddr      string   `mapstructure:"grpc_addr"`
	RESTAddr      string   `mapstructure:"rest_addr"`
	DashboardAddr string   `mapstructure:"dashboard_addr"`
	WebSocketAddr string   `mapstructure:"websocket_addr"`
	DataDir       string   `mapstructure:"data_dir"`
	LogLevel      string   `mapstructure:"log_level"`
	EnableEBPF    bool     `mapstructure:"enable_ebpf"`
	EnableMesh    bool     `mapstructure:"enable_mesh"`
	MeshPeers     []string `mapstructure:"mesh_peers"`
	DPI           DPIConfig `mapstructure:"dpi"`
}

type DPIConfig struct {
	Enabled       bool   `mapstructure:"enabled"`
	MimicProfile  string `mapstructure:"mimic_profile"`
	JitterEnabled bool   `mapstructure:"jitter_enabled"`
	JitterMaxMs   int    `mapstructure:"jitter_max_ms"`
}

func Default() *Config {
	return &Config{
		Role:          "kharej",
		NodeID:        "node-" + randomString(8),
		TunnelPort:    8443,
		Transports:    []string{"tcp", "quic", "webrtc", "wireguard", "kcp", "openvpn", "l2tp"},
		AutoTransport: true,
		GRPCAddr:      ":50051",
		RESTAddr:      ":8080",
		DashboardAddr: ":7777",
		WebSocketAddr: ":7778",
		DataDir:       "/var/lib/bomalo",
		LogLevel:      "info",
		EnableEBPF:    true,
		EnableMesh:    false,
		DPI: DPIConfig{
			Enabled:       true,
			MimicProfile:  "https",
			JitterEnabled: true,
			JitterMaxMs:   15,
		},
	}
}

func Load(path string) (*Config, error) {
	viper.SetConfigFile(path)
	viper.SetEnvPrefix("BOMALO")
	viper.AutomaticEnv()

	if err := viper.ReadInConfig(); err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}

	var cfg Config
	if err := viper.Unmarshal(&cfg); err != nil {
		return nil, fmt.Errorf("unmarshal config: %w", err)
	}
	return &cfg, nil
}

func (c *Config) Save(path string) error {
	viper.Set("role", c.Role)
	viper.Set("node_id", c.NodeID)
	viper.Set("token", c.Token)
	viper.Set("iran_addr", c.IranAddr)
	viper.Set("tunnel_port", c.TunnelPort)
	viper.Set("transports", c.Transports)
	viper.Set("auto_transport", c.AutoTransport)
	viper.Set("ports", c.Ports)
	viper.Set("grpc_addr", c.GRPCAddr)
	viper.Set("rest_addr", c.RESTAddr)
	viper.Set("dashboard_addr", c.DashboardAddr)
	viper.Set("enable_ebpf", c.EnableEBPF)
	viper.Set("enable_mesh", c.EnableMesh)
	return viper.WriteConfigAs(path)
}

func randomString(n int) string {
	const letters = "abcdefghijklmnopqrstuvwxyz0123456789"
	b := make([]byte, n)
	for i := range b {
		b[i] = letters[os.Getpid()%len(letters)]
	}
	return string(b)
}
