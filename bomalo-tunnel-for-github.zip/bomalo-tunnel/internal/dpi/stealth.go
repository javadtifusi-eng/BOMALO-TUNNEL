package dpi

import (
	"math/rand"
	"time"

	"github.com/yourusername/bomalo-tunnel/internal/config"
)

type Stealth struct {
	cfg *config.DPIConfig
}

func NewStealth(cfg *config.DPIConfig) *Stealth {
	return &Stealth{cfg: cfg}
}

func (s *Stealth) ShapeTraffic() time.Duration {
	if !s.cfg.Enabled {
		return 0
	}
	if !s.cfg.JitterEnabled {
		return 0
	}
	jitter := rand.Intn(s.cfg.JitterMaxMs)
	return time.Duration(jitter) * time.Millisecond
}

func (s *Stealth) MimicProfile() string {
	if !s.cfg.Enabled {
		return "none"
	}
	return s.cfg.MimicProfile
}

func (s *Stealth) ObfuscateHeader(data []byte) []byte {
	if !s.cfg.Enabled {
		return data
	}
	padding := make([]byte, rand.Intn(32))
	rand.Read(padding)
	return append(data, padding...)
}
