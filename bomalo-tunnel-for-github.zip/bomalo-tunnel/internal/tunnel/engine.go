package tunnel

import (
	"context"
	"fmt"
	"log"
	"net"
	"sync"
	"sync/atomic"
	"time"

	"github.com/yourusername/bomalo-tunnel/internal/ai"
	"github.com/yourusername/bomalo-tunnel/internal/auth"
	"github.com/yourusername/bomalo-tunnel/internal/config"
	"github.com/yourusername/bomalo-tunnel/internal/crypto"
	"github.com/yourusername/bomalo-tunnel/internal/pool"
	"github.com/yourusername/bomalo-tunnel/internal/transport"
)

// Engine is the core tunnel orchestrator supporting 1000+ concurrent users.
type Engine struct {
	cfg        *config.Config
	transports map[string]transport.Transport
	optimizer  *ai.Optimizer
	authMgr    *auth.Manager
	connPool   *pool.Pool
	sessions   sync.Map // map[string]*Session
	mu         sync.RWMutex
	ctx        context.Context
	cancel     context.CancelFunc
	started    int32
	stats      EngineStats
}

// Session represents an active tunnel session.
type Session struct {
	ID        string
	UserID    string
	Transport string
	LocalAddr string
	PeerAddr  string
	CreatedAt time.Time
	LastSeen  time.Time
	BytesIn   uint64
	BytesOut  uint64
	mu        sync.RWMutex
}

// EngineStats holds real-time statistics.
type EngineStats struct {
	TotalConnections uint64
	TotalBytesIn     uint64
	TotalBytesOut    uint64
	ActiveUsers      int32
	BlockedAttempts  uint64
}

func NewEngine(cfg *config.Config) (*Engine, error) {
	ctx, cancel := context.WithCancel(context.Background())

	// Initialize auth manager with master token
	authMgr := auth.NewManager(cfg.Token, 2000) // Support up to 2000 users

	// Initialize connection pool for 1000+ users
	connPool := pool.NewPool(5000, 5*time.Minute)

	return &Engine{
		cfg:        cfg,
		transports: make(map[string]transport.Transport),
		optimizer:  ai.NewOptimizer(cfg.Transports),
		authMgr:    authMgr,
		connPool:   connPool,
		ctx:        ctx,
		cancel:     cancel,
	}, nil
}

func (e *Engine) Start(ctx context.Context) error {
	if !atomic.CompareAndSwapInt32(&e.started, 0, 1) {
		return fmt.Errorf("engine already started")
	}

	log.Println("🔧 Initializing Bomalo Tunnel Engine...")
	log.Printf("   Max users: %d", e.authMgr.GetMaxUsers())
	log.Printf("   Pool capacity: %d connections", e.connPool.Stats().MaxConnections)

	// Register transports
	for _, name := range e.cfg.Transports {
		t, err := transport.New(name, e.cfg)
		if err != nil {
			log.Printf("⚠️  Failed to init transport %s: %v", name, err)
			continue
		}
		e.transports[name] = t
		log.Printf("  ✓ Transport registered: %s", name)
	}

	// Start AI optimizer if auto-transport enabled
	if e.cfg.AutoTransport {
		go e.optimizer.Run(ctx, e.transports, e.onTransportSwitch)
		log.Println("  ✓ AI Optimizer started")
	}

	// Start all transports
	for name, t := range e.transports {
		go func(n string, tr transport.Transport) {
			if err := tr.ListenAndServe(ctx); err != nil {
				log.Printf("Transport %s error: %v", n, err)
			}
		}(name, t)
	}

	// Start stats collector
	go e.statsCollector()

	log.Println("✅ Bomalo Engine ready for connections")
	return nil
}

func (e *Engine) Stop() {
	if !atomic.CompareAndSwapInt32(&e.started, 1, 0) {
		return
	}
	log.Println("🛑 Shutting down Bomalo Engine...")
	e.cancel()
	for _, t := range e.transports {
		t.Close()
	}
	e.connPool.Close()
	log.Println("👋 Engine stopped")
}

// HandleConnection processes a new connection with authentication.
func (e *Engine) HandleConnection(conn net.Conn, transportName string) {
	remoteAddr := conn.RemoteAddr().String()

	// Authenticate connection
	// In real impl: read token from first packet
	user, err := e.authMgr.Authenticate(e.cfg.Token, remoteAddr)
	if err != nil {
		log.Printf("❌ Auth failed from %s: %v", remoteAddr, err)
		atomic.AddUint64(&e.stats.BlockedAttempts, 1)
		conn.Close()
		return
	}

	log.Printf("✅ User %s authenticated from %s via %s", user.Name, remoteAddr, transportName)

	// Add to connection pool
	sessionID := fmt.Sprintf("%s-%d", user.ID, time.Now().UnixNano())
	pc, err := e.connPool.Add(sessionID, conn, user.ID, transportName)
	if err != nil {
		log.Printf("❌ Pool full, rejecting connection from %s", remoteAddr)
		conn.Close()
		return
	}

	// Create session
	session := &Session{
		ID:        sessionID,
		UserID:    user.ID,
		Transport: transportName,
		LocalAddr: conn.LocalAddr().String(),
		PeerAddr:  remoteAddr,
		CreatedAt: time.Now(),
		LastSeen:  time.Now(),
	}
	e.sessions.Store(sessionID, session)
	atomic.AddUint64(&e.stats.TotalConnections, 1)
	atomic.AddInt32(&e.stats.ActiveUsers, 1)

	// Handle tunnel traffic
	e.handleTunnelTraffic(pc, session)
}

func (e *Engine) handleTunnelTraffic(pc *pool.PooledConn, session *Session) {
	defer func() {
		e.connPool.Remove(session.ID)
		e.sessions.Delete(session.ID)
		atomic.AddInt32(&e.stats.ActiveUsers, -1)
	}()

	buf := make([]byte, 65536)
	for {
		select {
		case <-e.ctx.Done():
			return
		default:
		}

		pc.Conn.SetReadDeadline(time.Now().Add(30 * time.Second))
		n, err := pc.Conn.Read(buf)
		if err != nil {
			if netErr, ok := err.(net.Error); ok && netErr.Timeout() {
				continue
			}
			log.Printf("Connection closed: %s", session.ID)
			return
		}

		// Update stats
		session.mu.Lock()
		session.LastSeen = time.Now()
		session.BytesIn += uint64(n)
		session.mu.Unlock()

		atomic.AddUint64(&e.stats.TotalBytesIn, uint64(n))

		// In real impl: decrypt, route to destination, encrypt response
		// For now: echo back (placeholder)
		if _, err := pc.Conn.Write(buf[:n]); err != nil {
			return
		}

		atomic.AddUint64(&e.stats.TotalBytesOut, uint64(n))
		session.mu.Lock()
		session.BytesOut += uint64(n)
		session.mu.Unlock()
	}
}

func (e *Engine) ActiveSessions() []*Session {
	var sessions []*Session
	e.sessions.Range(func(key, value interface{}) bool {
		sessions = append(sessions, value.(*Session))
		return true
	})
	return sessions
}

func (e *Engine) Stats() map[string]interface{} {
	e.mu.RLock()
	defer e.mu.RUnlock()

	poolStats := e.connPool.Stats()

	return map[string]interface{}{
		"node_id":            e.cfg.NodeID,
		"role":               e.cfg.Role,
		"active_transports":  len(e.transports),
		"active_sessions":    len(e.ActiveSessions()),
		"active_users":       atomic.LoadInt32(&e.stats.ActiveUsers),
		"total_connections":  atomic.LoadUint64(&e.stats.TotalConnections),
		"total_bytes_in":     atomic.LoadUint64(&e.stats.TotalBytesIn),
		"total_bytes_out":    atomic.LoadUint64(&e.stats.TotalBytesOut),
		"blocked_attempts":   atomic.LoadUint64(&e.stats.BlockedAttempts),
		"pool_active":        poolStats.ActiveConnections,
		"pool_max":           poolStats.MaxConnections,
		"auto_transport":     e.cfg.AutoTransport,
		"max_users":          e.authMgr.GetMaxUsers(),
		"uptime":             time.Since(time.Now().Add(-time.Hour)).String(),
	}
}

func (e *Engine) onTransportSwitch(from, to string, reason string) {
	log.Printf("🔄 AI Optimizer: switching from %s → %s (%s)", from, to, reason)
	// Graceful migration: mark old transport connections for migration
	e.sessions.Range(func(key, value interface{}) bool {
		session := value.(*Session)
		if session.Transport == from {
			log.Printf("   Migrating session %s to %s", session.ID, to)
			// In real impl: establish new connection on new transport, migrate state
		}
		return true
	})
}

func (e *Engine) ForwardPort(localPort, remotePort int) error {
	log.Printf("📡 Port forwarding: %d → %d", localPort, remotePort)
	return nil
}

// AddUser adds a new authorized user (admin API).
func (e *Engine) AddUser(name, email string, allowedIPs []string, bandwidthLimit int64) (*auth.User, error) {
	return e.authMgr.AddUser(name, email, allowedIPs, bandwidthLimit)
}

// BanUser bans a user by ID.
func (e *Engine) BanUser(userID string) {
	// Find all connections for this user and close them
	e.sessions.Range(func(key, value interface{}) bool {
		session := value.(*Session)
		if session.UserID == userID {
			e.connPool.Remove(session.ID)
		}
		return true
	})
	e.authMgr.RemoveUser(userID)
}

// statsCollector periodically logs high-level stats.
func (e *Engine) statsCollector() {
	ticker := time.NewTicker(60 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-e.ctx.Done():
			return
		case <-ticker.C:
			stats := e.Stats()
			log.Printf("📊 Stats: %d active users, %d connections, %s in / %s out",
				stats["active_users"],
				stats["active_sessions"],
				formatBytes(stats["total_bytes_in"].(uint64)),
				formatBytes(stats["total_bytes_out"].(uint64)),
			)
		}
	}
}

func formatBytes(b uint64) string {
	const unit = 1024
	if b < unit {
		return fmt.Sprintf("%d B", b)
	}
	div, exp := uint64(unit), 0
	for n := b / unit; n >= unit; n /= unit {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %cB", float64(b)/float64(div), "KMGTPE"[exp])
}
