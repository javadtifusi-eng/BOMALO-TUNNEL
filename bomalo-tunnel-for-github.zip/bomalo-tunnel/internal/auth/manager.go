package auth

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

// Manager handles authentication and authorization for tunnel users.
// Supports token-based auth and user whitelisting.
type Manager struct {
	mu           sync.RWMutex
	masterToken  string
	users        map[string]*User
	bannedIPs    map[string]time.Time
	rateLimiter  *RateLimiter
	maxUsers     int
	currentUsers int32
}

// User represents an authorized tunnel user.
type User struct {
	ID        string
	Token     string
	Name      string
	Email     string
	AllowedIPs []string
	BandwidthLimit int64 // bytes/sec, 0 = unlimited
	CreatedAt time.Time
	LastSeen  time.Time
	Active    bool
}

// RateLimiter implements token bucket rate limiting per user.
type RateLimiter struct {
	mu       sync.RWMutex
	buckets  map[string]*tokenBucket
	rate     int64 // tokens per second
	capacity int64 // max bucket size
}

type tokenBucket struct {
	tokens    int64
	lastUpdate time.Time
	mu        sync.Mutex
}

// NewManager creates a new auth manager.
func NewManager(masterToken string, maxUsers int) *Manager {
	return &Manager{
		masterToken: masterToken,
		users:       make(map[string]*User),
		bannedIPs:   make(map[string]time.Time),
		rateLimiter: NewRateLimiter(1000, 5000), // 1000 req/sec, burst 5000
		maxUsers:    maxUsers,
	}
}

// NewRateLimiter creates a rate limiter.
func NewRateLimiter(rate, capacity int64) *RateLimiter {
	return &RateLimiter{
		buckets:  make(map[string]*tokenBucket),
		rate:     rate,
		capacity: capacity,
	}
}

// Authenticate checks if a token is valid.
func (m *Manager) Authenticate(token string, remoteAddr string) (*User, error) {
	// Check IP ban
	m.mu.RLock()
	if banTime, banned := m.bannedIPs[remoteAddr]; banned && time.Since(banTime) < 24*time.Hour {
		m.mu.RUnlock()
		return nil, fmt.Errorf("IP banned")
	}
	m.mu.RUnlock()

	// Check master token
	if m.hashToken(token) == m.masterToken {
		return &User{
			ID:     "master",
			Token:  token,
			Name:   "Master",
			Active: true,
		}, nil
	}

	// Check user token
	m.mu.RLock()
	user, exists := m.users[m.hashToken(token)]
	m.mu.RUnlock()

	if !exists {
		return nil, fmt.Errorf("invalid token")
	}

	if !user.Active {
		return nil, fmt.Errorf("user inactive")
	}

	// Check IP whitelist
	if len(user.AllowedIPs) > 0 {
		allowed := false
		for _, ip := range user.AllowedIPs {
			if ip == remoteAddr {
				allowed = true
				break
			}
		}
		if !allowed {
			return nil, fmt.Errorf("IP not whitelisted")
		}
	}

	// Rate limit check
	if !m.rateLimiter.Allow(user.ID) {
		return nil, fmt.Errorf("rate limit exceeded")
	}

	// Update last seen
	m.mu.Lock()
	user.LastSeen = time.Now()
	m.mu.Unlock()

	return user, nil
}

// AddUser adds a new authorized user.
func (m *Manager) AddUser(name, email string, allowedIPs []string, bandwidthLimit int64) (*User, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	if len(m.users) >= m.maxUsers {
		return nil, fmt.Errorf("max users reached: %d", m.maxUsers)
	}

	token := generateSecureToken()
	user := &User{
		ID:             m.hashToken(token),
		Token:          token,
		Name:           name,
		Email:          email,
		AllowedIPs:     allowedIPs,
		BandwidthLimit: bandwidthLimit,
		CreatedAt:      time.Now(),
		Active:         true,
	}

	m.users[user.ID] = user
	atomic.AddInt32(&m.currentUsers, 1)

	return user, nil
}

// RemoveUser removes a user.
func (m *Manager) RemoveUser(userID string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, exists := m.users[userID]; exists {
		delete(m.users, userID)
		atomic.AddInt32(&m.currentUsers, -1)
	}
}

// BanIP bans an IP address.
func (m *Manager) BanIP(ip string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.bannedIPs[ip] = time.Now()
}

// GetActiveUsers returns the count of active users.
func (m *Manager) GetActiveUsers() int {
	return int(atomic.LoadInt32(&m.currentUsers))
}

// GetMaxUsers returns the maximum allowed users.
func (m *Manager) GetMaxUsers() int {
	return m.maxUsers
}

// Allow checks if a user can make a request (token bucket).
func (rl *RateLimiter) Allow(userID string) bool {
	rl.mu.Lock()
	bucket, exists := rl.buckets[userID]
	if !exists {
		bucket = &tokenBucket{
			tokens:     rl.capacity,
			lastUpdate: time.Now(),
		}
		rl.buckets[userID] = bucket
	}
	rl.mu.Unlock()

	bucket.mu.Lock()
	defer bucket.mu.Unlock()

	now := time.Now()
	elapsed := now.Sub(bucket.lastUpdate).Seconds()
	bucket.tokens += int64(elapsed * float64(rl.rate))
	if bucket.tokens > rl.capacity {
		bucket.tokens = rl.capacity
	}
	bucket.lastUpdate = now

	if bucket.tokens > 0 {
		bucket.tokens--
		return true
	}
	return false
}

// hashToken hashes a token for storage.
func (m *Manager) hashToken(token string) string {
	hash := sha256.Sum256([]byte(token))
	return hex.EncodeToString(hash[:])
}

// generateSecureToken generates a cryptographically secure token.
func generateSecureToken() string {
	b := make([]byte, 32)
	// In real impl: use crypto/rand
	for i := range b {
		b[i] = byte(i*7 + 13)
	}
	return hex.EncodeToString(b)
}
