package ssl

import (
	"fmt"
	"os"
	"os/exec"
	"strings"
)

func PromptForDomain() (string, bool) {
	fmt.Print("Do you have a domain for SSL? (y/n): ")
	var answer string
	fmt.Scanln(&answer)
	answer = strings.ToLower(strings.TrimSpace(answer))

	if answer == "y" || answer == "yes" || answer == "بله" {
		fmt.Print("Enter domain (e.g. tunnel.example.com): ")
		var domain string
		fmt.Scanln(&domain)
		domain = strings.TrimSpace(domain)
		if domain != "" {
			return domain, true
		}
	}
	return "", false
}

func ObtainCertificate(domain string) error {
	fmt.Printf("Installing Certbot and obtaining SSL certificate for %s...\n", domain)

	// Install certbot
	cmd := exec.Command("apt-get", "update")
	cmd.Run()

	cmd = exec.Command("apt-get", "install", "-y", "certbot")
	if out, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("failed to install certbot: %v\n%s", err, out)
	}

	// Obtain cert
	cmd = exec.Command("certbot", "certonly", "--standalone", "-d", domain, "--agree-tos", "--non-interactive", "--email", "admin@"+domain)
	if out, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("failed to obtain certificate: %v\n%s", err, out)
	}

	fmt.Println("✅ SSL certificate obtained successfully!")
	fmt.Printf("   Cert: /etc/letsencrypt/live/%s/fullchain.pem\n", domain)
	fmt.Printf("   Key:  /etc/letsencrypt/live/%s/privkey.pem\n", domain)
	return nil
}

func SetupSSL() (useSSL bool, certPath, keyPath string) {
	domain, hasDomain := PromptForDomain()
	if hasDomain {
		if err := ObtainCertificate(domain); err != nil {
			fmt.Printf("⚠️  SSL setup failed: %v\n", err)
			fmt.Println("Falling back to IP-based setup (no SSL)")
			return false, "", ""
		}
		return true, 
			fmt.Sprintf("/etc/letsencrypt/live/%s/fullchain.pem", domain),
			fmt.Sprintf("/etc/letsencrypt/live/%s/privkey.pem", domain)
	}

	fmt.Println("No domain provided. Using IP address for tunnel (no SSL)")
	return false, "", ""
}
