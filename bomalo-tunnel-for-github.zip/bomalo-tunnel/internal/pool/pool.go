package pool

import (
	"net"
	"sync"
	"sync/atomic"
	"time"
)

// Pool manages a pool of tunnel connections for high-scale deployments.
// Optimized for 1000+ concurrent users.
type Pool struct {
	mu          sync.RWMutex
	connections map[string]*PooledConn
	maxConns    int32
	activeConns int32
	idleTimeout time.Duration
	cleanupTick *time.Ticker
}

// PooledConn wraps a net.Conn with metadata.
type PooledConn struct {
	Conn       net.Conn
	UserID     string
	Transport  string
	CreatedAt  time.Time
	LastUsed   time.Time
	BytesIn    uint64
	BytesOut   uint64
	mu         sync.RWMutex
}

// NewPool creates a new connection pool.
func NewPool(maxConnections int, idleTimeout time.Duration) *Pool {
	p := &Pool{
		connections: make(map[string]*PooledConn),
		maxConns:    int32(maxConnections),
		idleTimeout: idleTimeout,
		cleanupTick: time.NewTicker(30 * time.Second),
	}
	go p.cleanupWorker()
	return p
}

// Add adds a connection to the pool.
func (p *Pool) Add(id string, conn net.Conn, userID, transport string) (*PooledConn, error) {
	if atomic.LoadInt32(&p.activeConns) >= p.maxConns {
		return nil, ErrPoolFull
	}

	pc := &PooledConn{
		Conn:      conn,
		UserID:    userID,
		Transport: transport,
		CreatedAt: time.Now(),
		LastUsed:  time.Now(),
	}

	p.mu.Lock()
	p.connections[id] = pc
	p.mu.Unlock()
	atomic.AddInt32(&p.activeConns, 1)

	return pc, nil
}

// Get retrieves a connection by ID.
func (p *Pool) Get(id string) (*PooledConn, bool) {
	p.mu.RLock()
	pc, exists := p.connections[id]
	p.mu.RUnlock()

	if !exists {
		return nil, false
	}

	pc.mu.Lock()
	pc.LastUsed = time.Now()
	pc.mu.Unlock()

	return pc, true
}

// Remove removes a connection from the pool.
func (p *Pool) Remove(id string) {
	p.mu.Lock()
	pc, exists := p.connections[id]
	if exists {
		delete(p.connections, id)
	}
	p.mu.Unlock()

	if exists {
		pc.Conn.Close()
		atomic.AddInt32(&p.activeConns, -1)
	}
}

// Stats returns pool statistics.
func (p *Pool) Stats() PoolStats {
	p.mu.RLock()
	conns := len(p.connections)
	p.mu.RUnlock()

	return PoolStats{
		ActiveConnections: int(atomic.LoadInt32(&p.activeConns)),
		TotalConnections:  conns,
		MaxConnections:    int(p.maxConns),
	}
}

// cleanupWorker removes idle connections.
func (p *Pool) cleanupWorker() {
	for range p.cleanupTick.C {
		p.mu.Lock()
		now := time.Now()
		for id, pc := range p.connections {
			pc.mu.RLock()
			idle := now.Sub(pc.LastUsed)
			pc.mu.RUnlock()

			if idle > p.idleTimeout {
				pc.Conn.Close()
				delete(p.connections, id)
				atomic.AddInt32(&p.activeConns, -1)
			}
		}
		p.mu.Unlock()
	}
}

// Close closes all connections and stops the pool.
func (p *Pool) Close() {
	p.cleanupTick.Stop()
	p.mu.Lock()
	for _, pc := range p.connections {
		pc.Conn.Close()
	}
	p.connections = make(map[string]*PooledConn)
	p.mu.Unlock()
	atomic.StoreInt32(&p.activeConns, 0)
}

type PoolStats struct {
	ActiveConnections int
	TotalConnections  int
	MaxConnections    int
}

var ErrPoolFull = Error("connection pool full")

type Error string

func (e Error) Error() string { return string(e) }
