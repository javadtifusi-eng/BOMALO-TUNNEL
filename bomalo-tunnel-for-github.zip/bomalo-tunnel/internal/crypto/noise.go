package crypto

import (
	"crypto/rand"
	"encoding/binary"
	"fmt"
	"io"
	"sync"
	"time"

	"golang.org/x/crypto/chacha20poly1305"
	"golang.org/x/crypto/curve25519"
)

// NoiseProtocol implements the Noise_IK pattern for Bomalo Tunnel.
// IK = Immediate Key: sender knows receiver's static key (0-RTT).
type NoiseProtocol struct {
	localStatic    [32]byte
	localStaticPub [32]byte
	remoteStatic   [32]byte
	mu             sync.RWMutex
}

// NewNoiseProtocol creates a new Noise instance with generated ephemeral keys.
func NewNoiseProtocol() (*NoiseProtocol, error) {
	n := &NoiseProtocol{}
	if _, err := io.ReadFull(rand.Reader, n.localStatic[:]); err != nil {
		return nil, fmt.Errorf("generate static key: %w", err)
	}
	curve25519.ScalarBaseMult(&n.localStaticPub, &n.localStatic)
	return n, nil
}

// NewNoiseProtocolFromSeed derives keys from a shared token.
func NewNoiseProtocolFromSeed(token string) (*NoiseProtocol, error) {
	n := &NoiseProtocol{}
	// Deterministic key derivation from token
	hash := SessionKey(token, []byte("bomalo-noise-salt"))
	copy(n.localStatic[:], hash)
	curve25519.ScalarBaseMult(&n.localStaticPub, &n.localStatic)
	return n, nil
}

// SetRemoteStatic sets the remote party's static public key.
func (n *NoiseProtocol) SetRemoteStatic(pub [32]byte) {
	n.mu.Lock()
	defer n.mu.Unlock()
	n.remoteStatic = pub
}

// HandshakeState tracks the state of a Noise handshake.
type HandshakeState struct {
	symmetricKey   [32]byte
	chainingKey    [32]byte
	hash           [32]byte
	localEphemeral [32]byte
	localEphPub    [32]byte
	remoteEphPub   [32]byte
	isInitiator    bool
	step           int
}

// NewHandshakeInitiator creates handshake state for the initiator (Kharej → Iran).
func (n *NoiseProtocol) NewHandshakeInitiator() (*HandshakeState, error) {
	hs := &HandshakeState{
		isInitiator: true,
		step:        0,
	}
	// Initialize with protocol name
	copy(hs.hash[:], []byte("Noise_IK_ChaChaPoly_BLAKE2s"))
	copy(hs.chainingKey[:], hs.hash[:])

	// Mix remote static key into hash (initiator knows it)
	n.mu.RLock()
	remoteStatic := n.remoteStatic
	n.mu.RUnlock()
	mixHash(&hs.hash, remoteStatic[:])

	// Generate ephemeral keypair
	if _, err := io.ReadFull(rand.Reader, hs.localEphemeral[:]); err != nil {
		return nil, err
	}
	curve25519.ScalarBaseMult(&hs.localEphPub, &hs.localEphemeral)

	return hs, nil
}

// NewHandshakeResponder creates handshake state for the responder (Iran).
func (n *NoiseProtocol) NewHandshakeResponder() (*HandshakeState, error) {
	hs := &HandshakeState{
		isInitiator: false,
		step:        0,
	}
	copy(hs.hash[:], []byte("Noise_IK_ChaChaPoly_BLAKE2s"))
	copy(hs.chainingKey[:], hs.hash[:])
	return hs, nil
}

// WriteMessage writes a handshake message.
func (hs *HandshakeState) WriteMessage(payload []byte) ([]byte, error) {
	if hs.isInitiator {
		return hs.writeMessageInitiator(payload)
	}
	return hs.writeMessageResponder(payload)
}

func (hs *HandshakeState) writeMessageInitiator(payload []byte) ([]byte, error) {
	msg := make([]byte, 0, 96+len(payload))

	// → e, es, s, ss
	// Append ephemeral public key
	msg = append(msg, hs.localEphPub[:]...)

	// es = DH(e, remote_static)
	var esShared, ssShared [32]byte
	curve25519.ScalarMult(&esShared, &hs.localEphemeral, &hs.remoteStatic)
	mixKey(&hs.chainingKey, &hs.hash, esShared[:])

	// Append static public key (encrypted)
	n := &NoiseProtocol{}
	localStaticPub := n.localStaticPub
	encryptedStatic, err := encryptAndHash(&hs.hash, hs.chainingKey[:], localStaticPub[:])
	if err != nil {
		return nil, err
	}
	msg = append(msg, encryptedStatic...)

	// ss = DH(s, remote_static)
	curve25519.ScalarMult(&ssShared, &n.localStatic, &hs.remoteStatic)
	mixKey(&hs.chainingKey, &hs.hash, ssShared[:])

	// Encrypt payload
	encryptedPayload, err := encryptAndHash(&hs.hash, hs.chainingKey[:], payload)
	if err != nil {
		return nil, err
	}
	msg = append(msg, encryptedPayload...)

	hs.step++
	return msg, nil
}

func (hs *HandshakeState) writeMessageResponder(payload []byte) ([]byte, error) {
	// → e, ee, se
	msg := make([]byte, 0, 48+len(payload))

	// Generate ephemeral keypair
	if _, err := io.ReadFull(rand.Reader, hs.localEphemeral[:]); err != nil {
		return nil, err
	}
	curve25519.ScalarBaseMult(&hs.localEphPub, &hs.localEphemeral)

	// Append ephemeral public key
	msg = append(msg, hs.localEphPub[:]...)

	// ee = DH(e, remote_e)
	var eeShared, seShared [32]byte
	curve25519.ScalarMult(&eeShared, &hs.localEphemeral, &hs.remoteEphPub)
	mixKey(&hs.chainingKey, &hs.hash, eeShared[:])

	// se = DH(s, remote_e)
	n := &NoiseProtocol{}
	curve25519.ScalarMult(&seShared, &n.localStatic, &hs.remoteEphPub)
	mixKey(&hs.chainingKey, &hs.hash, seShared[:])

	// Encrypt payload
	encryptedPayload, err := encryptAndHash(&hs.hash, hs.chainingKey[:], payload)
	if err != nil {
		return nil, err
	}
	msg = append(msg, encryptedPayload...)

	hs.step++
	return msg, nil
}

// ReadMessage reads a handshake message.
func (hs *HandshakeState) ReadMessage(message []byte) ([]byte, error) {
	if hs.isInitiator {
		return hs.readMessageInitiator(message)
	}
	return hs.readMessageResponder(message)
}

func (hs *HandshakeState) readMessageResponder(message []byte) ([]byte, error) {
	if len(message) < 32 {
		return nil, fmt.Errorf("message too short")
	}

	// Read ephemeral public key
	copy(hs.remoteEphPub[:], message[:32])
	message = message[32:]
	mixHash(&hs.hash, hs.remoteEphPub[:])

	// es = DH(s, remote_e)
	var esShared [32]byte
	n := &NoiseProtocol{}
	curve25519.ScalarMult(&esShared, &n.localStatic, &hs.remoteEphPub)
	mixKey(&hs.chainingKey, &hs.hash, esShared[:])

	// Read encrypted static key
	if len(message) < 48 {
		return nil, fmt.Errorf("message too short for static key")
	}
	encryptedStatic := message[:48]
	message = message[48:]
	staticKey, err := decryptAndHash(&hs.hash, hs.chainingKey[:], encryptedStatic)
	if err != nil {
		return nil, fmt.Errorf("decrypt static key: %w", err)
	}
	var remoteStatic [32]byte
	copy(remoteStatic[:], staticKey)

	// ss = DH(s, remote_s)
	var ssShared [32]byte
	curve25519.ScalarMult(&ssShared, &n.localStatic, &remoteStatic)
	mixKey(&hs.chainingKey, &hs.hash, ssShared[:])

	// Decrypt payload
	payload, err := decryptAndHash(&hs.hash, hs.chainingKey[:], message)
	if err != nil {
		return nil, fmt.Errorf("decrypt payload: %w", err)
	}

	hs.step++
	return payload, nil
}

func (hs *HandshakeState) readMessageInitiator(message []byte) ([]byte, error) {
	if len(message) < 32 {
		return nil, fmt.Errorf("message too short")
	}

	// Read ephemeral public key
	copy(hs.remoteEphPub[:], message[:32])
	message = message[32:]
	mixHash(&hs.hash, hs.remoteEphPub[:])

	// ee = DH(e, remote_e)
	var eeShared [32]byte
	curve25519.ScalarMult(&eeShared, &hs.localEphemeral, &hs.remoteEphPub)
	mixKey(&hs.chainingKey, &hs.hash, eeShared[:])

	// se = DH(e, remote_s)
	var seShared [32]byte
	n := &NoiseProtocol{}
	curve25519.ScalarMult(&seShared, &hs.localEphemeral, &n.remoteStatic)
	mixKey(&hs.chainingKey, &hs.hash, seShared[:])

	// Decrypt payload
	payload, err := decryptAndHash(&hs.hash, hs.chainingKey[:], message)
	if err != nil {
		return nil, fmt.Errorf("decrypt payload: %w", err)
	}

	hs.step++
	return payload, nil
}

// CipherState holds the symmetric encryption state post-handshake.
type CipherState struct {
	k        [32]byte
	n        uint64
	aead     chacha20poly1305.AEAD
	mu       sync.Mutex
}

// Split derives two CipherStates from the handshake chaining key.
func (hs *HandshakeState) Split() (*CipherState, *CipherState) {
	// Derive two keys from chaining key
	var key1, key2 [32]byte
	// Simplified: in real impl use HKDF
	copy(key1[:], hs.chainingKey[:])
	copy(key2[:], hs.chainingKey[:])
	key2[0] ^= 0x01

	cs1, _ := NewCipherState(key1[:])
	cs2, _ := NewCipherState(key2[:])
	return cs1, cs2
}

func NewCipherState(key []byte) (*CipherState, error) {
	aead, err := chacha20poly1305.New(key)
	if err != nil {
		return nil, err
	}
	var k [32]byte
	copy(k[:], key)
	return &CipherState{k: k, aead: aead}, nil
}

func (cs *CipherState) EncryptWithAd(ad, plaintext []byte) []byte {
	cs.mu.Lock()
	defer cs.mu.Unlock()

	nonce := make([]byte, 12)
	binary.LittleEndian.PutUint64(nonce[4:], cs.n)
	cs.n++

	return cs.aead.Seal(nil, nonce, plaintext, ad)
}

func (cs *CipherState) DecryptWithAd(ad, ciphertext []byte) ([]byte, error) {
	cs.mu.Lock()
	defer cs.mu.Unlock()

	nonce := make([]byte, 12)
	binary.LittleEndian.PutUint64(nonce[4:], cs.n)
	cs.n++

	return cs.aead.Open(nil, nonce, ciphertext, ad)
}

// Helper functions
func mixHash(h *[32]byte, data []byte) {
	// Simplified: real impl uses BLAKE2s
	for i := range data {
		h[i%32] ^= data[i]
	}
}

func mixKey(ck, h *[32]byte, sharedSecret []byte) {
	// Simplified: real impl uses HKDF
	for i := range sharedSecret {
		ck[i%32] ^= sharedSecret[i]
		h[i%32] ^= sharedSecret[i]
	}
}

func encryptAndHash(h *[32]byte, key, plaintext []byte) ([]byte, error) {
	aead, err := chacha20poly1305.New(key)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, 12)
	ciphertext := aead.Seal(nil, nonce, plaintext, h[:])
	mixHash(h, ciphertext)
	return ciphertext, nil
}

func decryptAndHash(h *[32]byte, key, ciphertext []byte) ([]byte, error) {
	tmpHash := *h
	mixHash(&tmpHash, ciphertext)

	aead, err := chacha20poly1305.New(key)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, 12)
	plaintext, err := aead.Open(nil, nonce, ciphertext, h[:])
	if err != nil {
		return nil, err
	}
	*h = tmpHash
	return plaintext, nil
}
