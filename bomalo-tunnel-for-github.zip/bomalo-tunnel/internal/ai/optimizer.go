package ai

import (
	"context"
	"log"
	"math"
	"time"

	"github.com/yourusername/bomalo-tunnel/internal/transport"
)

type Optimizer struct {
	transportNames []string
	currentBest    string
	windowSize     int
}

func NewOptimizer(names []string) *Optimizer {
	return &Optimizer{
		transportNames: names,
		currentBest:    names[0],
		windowSize:     10,
	}
}

func (o *Optimizer) Run(ctx context.Context, transports map[string]transport.Transport, onSwitch func(from, to, reason string)) {
	ticker := time.NewTicker(15 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			best := o.evaluate(transports)
			if best != "" && best != o.currentBest {
				reason := o.reason(transports, o.currentBest, best)
				onSwitch(o.currentBest, best, reason)
				o.currentBest = best
			}
		}
	}
}

func (o *Optimizer) evaluate(transports map[string]transport.Transport) string {
	var best string
	bestScore := -9999.0

	for name, tr := range transports {
		h := tr.Health()
		if !h.Available {
			continue
		}
		score := 100.0 - (h.RTT*0.4 + h.Jitter*2.0 + h.LossRate*2000.0)
		score = math.Max(0, math.Min(100, score))

		log.Printf("[AI] %s → RTT:%.1fms Jitter:%.1fms Loss:%.3f%% Score:%.1f",
			name, h.RTT, h.Jitter, h.LossRate*100, score)

		if score > bestScore {
			bestScore = score
			best = name
		}
	}
	return best
}

func (o *Optimizer) reason(transports map[string]transport.Transport, from, to string) string {
	oldH := transports[from].Health()
	newH := transports[to].Health()
	if newH.RTT < oldH.RTT*0.7 {
		return "significantly lower latency"
	}
	if newH.LossRate < oldH.LossRate*0.5 {
		return "packet loss reduction"
	}
	if newH.Jitter < oldH.Jitter*0.6 {
		return "better stability"
	}
	return "overall health improvement"
}
