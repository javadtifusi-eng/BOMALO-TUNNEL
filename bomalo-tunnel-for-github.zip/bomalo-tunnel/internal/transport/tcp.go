package transport

import (
	"context"
	"fmt"
	"net"
	"sync"
	"time"

	"github.com/yourusername/bomalo-tunnel/internal/config"
)

type TCPTransport struct {
	cfg    *config.Config
	ln     net.Listener
	mu     sync.Mutex
	rtt    float64
	loss   float64
	closed bool
}

func NewTCPTransport(cfg *config.Config) *TCPTransport {
	return &TCPTransport{cfg: cfg}
}

func (t *TCPTransport) Name() string { return "tcp" }

func (t *TCPTransport) ListenAndServe(ctx context.Context) error {
	addr := fmt.Sprintf(":%d", t.cfg.TunnelPort)
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return err
	}
	t.ln = ln
	defer ln.Close()

	for {
		conn, err := ln.Accept()
		if err != nil {
			select {
			case <-ctx.Done():
				return nil
			default:
				continue
			}
		}
		go t.handleConn(ctx, conn)
	}
}

func (t *TCPTransport) handleConn(ctx context.Context, conn net.Conn) {
	defer conn.Close()
	buf := make([]byte, 4096)
	for {
		conn.SetReadDeadline(time.Now().Add(30 * time.Second))
		n, err := conn.Read(buf)
		if err != nil {
			return
		}
		_ = n
	}
}

func (t *TCPTransport) Dial(ctx context.Context, addr string) (net.Conn, error) {
	d := net.Dialer{Timeout: 10 * time.Second}
	return d.DialContext(ctx, "tcp", addr)
}

func (t *TCPTransport) Close() error {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.closed = true
	if t.ln != nil {
		return t.ln.Close()
	}
	return nil
}

func (t *TCPTransport) Health() HealthSnapshot {
	return HealthSnapshot{
		RTT:       t.rtt,
		Jitter:    0,
		LossRate:  t.loss,
		Available: !t.closed,
		Score:     70,
	}
}
