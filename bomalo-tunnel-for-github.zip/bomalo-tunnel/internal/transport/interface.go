package transport

import (
	"context"
	"fmt"
	"net"

	"github.com/yourusername/bomalo-tunnel/internal/config"
)

type Transport interface {
	Name() string
	ListenAndServe(ctx context.Context) error
	Dial(ctx context.Context, addr string) (net.Conn, error)
	Close() error
	Health() HealthSnapshot
}

type HealthSnapshot struct {
	RTT       float64
	Jitter    float64
	LossRate  float64
	Available bool
	Score     float64
}

func New(name string, cfg *config.Config) (Transport, error) {
	switch name {
	case "tcp":
		return NewTCPTransport(cfg), nil
	case "quic":
		return NewQUICTransport(cfg), nil
	case "webrtc":
		return NewWebRTCTransport(cfg), nil
	case "wireguard":
		return NewWireGuardTransport(cfg), nil
	case "kcp":
		return NewKCPTransport(cfg), nil
	case "openvpn":
		return NewOpenVPNTransport(cfg), nil
	case "l2tp":
		return NewL2TPTransport(cfg), nil
	default:
		return nil, fmt.Errorf("unknown transport: %s", name)
	}
}
