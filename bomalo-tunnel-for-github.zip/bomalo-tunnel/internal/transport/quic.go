package transport

import (
	"context"
	"crypto/tls"
	"fmt"
	"net"
	"sync"

	"github.com/quic-go/quic-go"
	"github.com/yourusername/bomalo-tunnel/internal/config"
)

type QUICTransport struct {
	cfg    *config.Config
	ln     *quic.Listener
	mu     sync.Mutex
	closed bool
}

func NewQUICTransport(cfg *config.Config) *QUICTransport {
	return &QUICTransport{cfg: cfg}
}

func (t *QUICTransport) Name() string { return "quic" }

func (t *QUICTransport) ListenAndServe(ctx context.Context) error {
	addr := fmt.Sprintf(":%d", t.cfg.TunnelPort+1)
	ln, err := quic.ListenAddr(addr, generateTLSConfig(), &quic.Config{})
	if err != nil {
		return err
	}
	t.ln = ln
	defer ln.Close()

	for {
		sess, err := ln.Accept(ctx)
		if err != nil {
			select {
			case <-ctx.Done():
				return nil
			default:
				continue
			}
		}
		go t.handleSession(ctx, sess)
	}
}

func (t *QUICTransport) handleSession(ctx context.Context, sess quic.Connection) {
	for {
		stream, err := sess.AcceptStream(ctx)
		if err != nil {
			return
		}
		go func(s quic.Stream) {
			defer s.Close()
		}(stream)
	}
}

func (t *QUICTransport) Dial(ctx context.Context, addr string) (net.Conn, error) {
	sess, err := quic.DialAddr(ctx, addr, generateTLSConfig(), &quic.Config{})
	if err != nil {
		return nil, err
	}
	stream, err := sess.OpenStreamSync(ctx)
	if err != nil {
		return nil, err
	}
	return &quicConn{sess: sess, stream: stream}, nil
}

func (t *QUICTransport) Close() error {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.closed = true
	if t.ln != nil {
		return t.ln.Close()
	}
	return nil
}

func (t *QUICTransport) Health() HealthSnapshot {
	return HealthSnapshot{
		RTT:       45,
		Jitter:    2,
		LossRate:  0,
		Available: !t.closed,
		Score:     95,
	}
}

type quicConn struct {
	sess   quic.Connection
	stream quic.Stream
}

func (c *quicConn) Read(b []byte) (int, error)  { return c.stream.Read(b) }
func (c *quicConn) Write(b []byte) (int, error) { return c.stream.Write(b) }
func (c *quicConn) Close() error                { return c.stream.Close() }
func (c *quicConn) LocalAddr() net.Addr         { return c.sess.LocalAddr() }
func (c *quicConn) RemoteAddr() net.Addr        { return c.sess.RemoteAddr() }

func generateTLSConfig() *tls.Config { return &tls.Config{InsecureSkipVerify: true} }
