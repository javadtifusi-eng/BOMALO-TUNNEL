package nettest

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"os/exec"
	"strings"
	"time"
)

type Result struct {
	TestName string
	Success  bool
	Latency  time.Duration
	Error    string
	Details  string
}

// GetPublicIP returns the server's public IPv4
func GetPublicIP() (string, error) {
	resp, err := http.Get("https://api.ipify.org?format=text")
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	buf := make([]byte, 64)
	n, _ := resp.Body.Read(buf)
	return strings.TrimSpace(string(buf[:n])), nil
}

// TestGoogleDNS checks if 8.8.8.8 is reachable
func TestGoogleDNS() Result {
	start := time.Now()
	conn, err := net.DialTimeout("udp", "8.8.8.8:53", 5*time.Second)
	if err != nil {
		return Result{TestName: "Google DNS", Success: false, Latency: time.Since(start), Error: err.Error()}
	}
	defer conn.Close()
	return Result{TestName: "Google DNS", Success: true, Latency: time.Since(start), Details: "8.8.8.8:53 reachable"}
}

// TestConnectivity tries TCP connection to target
func TestConnectivity(target string, port int) Result {
	start := time.Now()
	addr := fmt.Sprintf("%s:%d", target, port)
	conn, err := net.DialTimeout("tcp", addr, 10*time.Second)
	if err != nil {
		return Result{TestName: fmt.Sprintf("TCP to %s:%d", target, port), Success: false, Latency: time.Since(start), Error: err.Error()}
	}
	defer conn.Close()
	return Result{TestName: fmt.Sprintf("TCP to %s:%d", target, port), Success: true, Latency: time.Since(start), Details: "TCP handshake OK"}
}

// TestPing runs ICMP ping (requires root or CAP_NET_RAW)
func TestPing(target string) Result {
	start := time.Now()
	cmd := exec.CommandContext(context.Background(), "ping", "-c", "3", "-W", "5", target)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return Result{TestName: fmt.Sprintf("Ping %s", target), Success: false, Latency: time.Since(start), Error: string(out)}
	}
	return Result{TestName: fmt.Sprintf("Ping %s", target), Success: true, Latency: time.Since(start), Details: strings.TrimSpace(string(out))}
}

// TestIranToKharej runs full test from Iran side
func TestIranToKharej(kharejIP string) []Result {
	var results []Result
	results = append(results, TestGoogleDNS())
	results = append(results, TestConnectivity(kharejIP, 22))
	results = append(results, TestPing(kharejIP))
	return results
}

// TestKharejToIran runs full test from Kharej side
func TestKharejToIran(iranIP string) []Result {
	var results []Result
	results = append(results, TestGoogleDNS())
	results = append(results, TestConnectivity(iranIP, 22))
	results = append(results, TestPing(iranIP))
	return results
}

// AllPassed returns true if all tests passed
func AllPassed(results []Result) bool {
	for _, r := range results {
		if !r.Success {
			return false
		}
	}
	return true
}
