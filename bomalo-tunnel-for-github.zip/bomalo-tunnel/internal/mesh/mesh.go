package mesh

import (
	"context"
	"fmt"
	"log"
	"sync"
	"time"
)

type Node struct {
	ID       string
	Endpoint string
	Region   string
	Healthy  bool
	RTT      time.Duration
	LastSeen time.Time
}

type Router struct {
	mu     sync.RWMutex
	nodes  map[string]*Node
	peers  []string
	ctx    context.Context
	cancel context.CancelFunc
}

func NewRouter(peers []string) *Router {
	ctx, cancel := context.WithCancel(context.Background())
	return &Router{
		nodes:  make(map[string]*Node),
		peers:  peers,
		ctx:    ctx,
		cancel: cancel,
	}
}

func (r *Router) Start() {
	if len(r.peers) == 0 {
		return
	}
	log.Println("🕸️  Mesh router starting with peers:", r.peers)
	go r.healthCheckLoop()
}

func (r *Router) Stop() {
	r.cancel()
}

func (r *Router) healthCheckLoop() {
	ticker := time.NewTicker(10 * time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-r.ctx.Done():
			return
		case <-ticker.C:
			r.probePeers()
		}
	}
}

func (r *Router) probePeers() {
	for _, addr := range r.peers {
		start := time.Now()
		rtt := time.Since(start)

		r.mu.Lock()
		r.nodes[addr] = &Node{
			ID:       addr,
			Endpoint: addr,
			Healthy:  true,
			RTT:      rtt,
			LastSeen: time.Now(),
		}
		r.mu.Unlock()
	}
}

func (r *Router) BestNode() *Node {
	r.mu.RLock()
	defer r.mu.RUnlock()

	var best *Node
	for _, n := range r.nodes {
		if !n.Healthy {
			continue
		}
		if best == nil || n.RTT < best.RTT {
			best = n
		}
	}
	return best
}

func (r *Router) Nodes() []*Node {
	r.mu.RLock()
	defer r.mu.RUnlock()
	var out []*Node
	for _, n := range r.nodes {
		out = append(out, n)
	}
	return out
}

func (r *Router) Join(token string) error {
	fmt.Printf("🔗 Joining mesh with token: %s...\n", token[:8])
	return nil
}
