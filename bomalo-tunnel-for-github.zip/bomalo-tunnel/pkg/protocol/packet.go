package protocol

import (
	"encoding/binary"
	"fmt"
	"time"
)

const (
	MagicByte  = 0x42
	Version    = 1
	HeaderSize = 16
	MaxPayload = 65535
)

type PacketType uint8

const (
	PacketTypeData      PacketType = 0x01
	PacketTypeHeartbeat PacketType = 0x02
	PacketTypeControl   PacketType = 0x03
	PacketTypeSwitch    PacketType = 0x04
)

type Header struct {
	Magic     uint8
	Version   uint8
	Type      PacketType
	Flags     uint8
	SessionID uint32
	Length    uint16
	Reserved  uint16
	Timestamp uint32
}

func (h *Header) Encode() []byte {
	b := make([]byte, HeaderSize)
	b[0] = h.Magic
	b[1] = h.Version
	b[2] = uint8(h.Type)
	b[3] = h.Flags
	binary.BigEndian.PutUint32(b[4:8], h.SessionID)
	binary.BigEndian.PutUint16(b[8:10], h.Length)
	binary.BigEndian.PutUint16(b[10:12], h.Reserved)
	binary.BigEndian.PutUint32(b[12:16], h.Timestamp)
	return b
}

func DecodeHeader(data []byte) (*Header, error) {
	if len(data) < HeaderSize {
		return nil, fmt.Errorf("short header")
	}
	if data[0] != MagicByte {
		return nil, fmt.Errorf("invalid magic: 0x%02x", data[0])
	}
	return &Header{
		Magic:     data[0],
		Version:   data[1],
		Type:      PacketType(data[2]),
		Flags:     data[3],
		SessionID: binary.BigEndian.Uint32(data[4:8]),
		Length:    binary.BigEndian.Uint16(data[8:10]),
		Reserved:  binary.BigEndian.Uint16(data[10:12]),
		Timestamp: binary.BigEndian.Uint32(data[12:16]),
	}, nil
}

func NewHeader(ptype PacketType, sessionID uint32, payloadLen uint16) *Header {
	return &Header{
		Magic:     MagicByte,
		Version:   Version,
		Type:      ptype,
		SessionID: sessionID,
		Length:    payloadLen,
		Timestamp: uint32(time.Now().Unix()),
	}
}
