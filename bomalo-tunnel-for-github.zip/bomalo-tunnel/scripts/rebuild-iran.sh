#!/bin/bash
# Bomalo Tunnel - Iran Server Rebuild Script
# This script completely rebuilds the Iran (entry) server

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║${GREEN}        🌐  B O M A L O   T U N N E L  -  R E B U I L D       ${CYAN}║${NC}"
echo -e "${CYAN}║${YELLOW}                   Iran Server (Entry Point)                    ${CYAN}║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# === STEP 1: BACKUP ===
echo -e "${BLUE}[1/8] Creating backup before rebuild...${NC}"
BACKUP_DIR="/root/bomalo-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"
if [ -f /etc/bomalo/config.yaml ]; then
    cp /etc/bomalo/config.yaml "$BACKUP_DIR/"
    echo -e "${GREEN}✓ Config backed up to $BACKUP_DIR${NC}"
fi
if [ -d /var/lib/bomalo ]; then
    cp -r /var/lib/bomalo "$BACKUP_DIR/"
    echo -e "${GREEN}✓ Data backed up${NC}"
fi

# === STEP 2: STOP SERVICES ===
echo -e "${BLUE}[2/8] Stopping Bomalo services...${NC}"
systemctl stop bomalo 2>/dev/null || true
systemctl disable bomalo 2>/dev/null || true
pkill -f bomalo 2>/dev/null || true
pkill -f bomalod 2>/dev/null || true
echo -e "${GREEN}✓ Services stopped${NC}"

# === STEP 3: CLEANUP ===
echo -e "${BLUE}[3/8] Cleaning up old installation...${NC}"
rm -rf /usr/local/bin/bomalo /usr/local/bin/bomalod
rm -rf /etc/bomalo
rm -rf /var/lib/bomalo
rm -f /etc/systemd/system/bomalo.service
systemctl daemon-reload
echo -e "${GREEN}✓ Old installation removed${NC}"

# === STEP 4: SYSTEM UPDATE ===
echo -e "${BLUE}[4/8] Updating system packages...${NC}"
apt-get update -qq
apt-get upgrade -y -qq
echo -e "${GREEN}✓ System updated${NC}"

# === STEP 5: INSTALL DEPENDENCIES ===
echo -e "${BLUE}[5/8] Installing dependencies...${NC}"
apt-get install -y -qq \
    curl wget git \
    iptables iproute2 \
    net-tools dnsutils \
    ca-certificates \
    systemd-timesyncd \
    linux-headers-$(uname -r) 2>/dev/null || true
echo -e "${GREEN}✓ Dependencies installed${NC}"

# === STEP 6: NETWORK OPTIMIZATION ===
echo -e "${BLUE}[6/8] Applying network optimizations...${NC}"
cat >> /etc/sysctl.conf << 'EOF'
# Bomalo Tunnel Optimizations
net.ipv4.ip_forward=1
net.ipv6.conf.all.forwarding=1
net.core.rmem_max=134217728
net.core.wmem_max=134217728
net.ipv4.tcp_rmem=4096 87380 134217728
net.ipv4.tcp_wmem=4096 65536 134217728
net.core.netdev_max_backlog=300000
net.ipv4.tcp_congestion_control=bbr
net.ipv4.tcp_notsent_lowat=16384
net.ipv4.tcp_fastopen=3
fs.file-max=2097152
EOF
sysctl -p >/dev/null 2>&1
echo -e "${GREEN}✓ Network optimized (BBR enabled)${NC}"

# === STEP 7: INSTALL BOMALO ===
echo -e "${BLUE}[7/8] Installing Bomalo Tunnel...${NC}"

# Download latest release
ARCH=$(uname -m)
case $ARCH in
    x86_64)  BIN_ARCH="amd64" ;;
    aarch64) BIN_ARCH="arm64" ;;
    *)       BIN_ARCH="amd64" ;;
esac

REPO="yourusername/bomalo-tunnel"
LATEST=$(curl -s "https://api.github.com/repos/$REPO/releases/latest" | grep '"tag_name":' | sed -E 's/.*"([^"]+)".*/\1/')
[ -z "$LATEST" ] && LATEST="v1.0.0"

echo -e "${YELLOW}   Downloading $LATEST for $BIN_ARCH...${NC}"
URL="https://github.com/$REPO/releases/download/$LATEST/bomalo-linux-$BIN_ARCH.tar.gz"

cd /tmp
curl -fsSL "$URL" -o bomalo.tar.gz 2>/dev/null || {
    echo -e "${RED}   Download failed. Building from source...${NC}"
    apt-get install -y -qq golang-go
    git clone "https://github.com/$REPO.git" /tmp/bomalo-src
    cd /tmp/bomalo-src
    make build
    cp bin/bomalo /usr/local/bin/
    cp bin/bomalod /usr/local/bin/
}

if [ -f bomalo.tar.gz ]; then
    tar -xzf bomalo.tar.gz
    install -Dm755 bomalo /usr/local/bin/bomalo
    install -Dm755 bomalod /usr/local/bin/bomalod
fi

echo -e "${GREEN}✓ Bomalo installed${NC}"

# === STEP 8: CONFIGURE ===
echo -e "${BLUE}[8/8] Configuring Iran server...${NC}"

mkdir -p /etc/bomalo /var/lib/bomalo

# Generate secure token
TOKEN=$(openssl rand -hex 32)

# Get public IP
PUBLIC_IP=$(curl -fsSL --connect-timeout 10 https://api.ipify.org 2>/dev/null || echo "YOUR_IP")

cat > /etc/bomalo/config.yaml << EOF
role: iran
node_id: iran-$(openssl rand -hex 4)
token: $TOKEN
tunnel_port: 8443
transports:
  - tcp
  - quic
  - webrtc
  - wireguard
  - kcp
  - openvpn
  - l2tp
auto_transport: true
ports:
  - 443
  - 8080
  - 8443
grpc_addr: ":50051"
rest_addr: ":8080"
dashboard_addr: ":7777"
websocket_addr: ":7778"
data_dir: "/var/lib/bomalo"
log_level: info
enable_ebpf: true
enable_mesh: false
dpi:
  enabled: true
  mimic_profile: https
  jitter_enabled: true
  jitter_max_ms: 15
EOF

# Install systemd service
cat > /etc/systemd/system/bomalo.service << 'EOF'
[Unit]
Description=Bomalo Tunnel Daemon
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/bin/bomalod --config /etc/bomalo/config.yaml
Restart=always
RestartSec=5
LimitNOFILE=1048576
LimitNPROC=4096

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable bomalo

# === FINAL OUTPUT ===
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║${CYAN}              ✅ Iran Server Rebuild Complete!                  ${GREEN}║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}📡 Server IP:${NC} $PUBLIC_IP"
echo -e "${YELLOW}🔑 Master Token:${NC} ${GREEN}$TOKEN${NC}"
echo -e "${YELLOW}📂 Config:${NC} /etc/bomalo/config.yaml"
echo ""
echo -e "${CYAN}🚀 Starting Bomalo...${NC}"
systemctl start bomalo
sleep 2

if systemctl is-active --quiet bomalo; then
    echo -e "${GREEN}✅ Bomalo is running!${NC}"
else
    echo -e "${RED}❌ Failed to start Bomalo. Check: journalctl -u bomalo -f${NC}"
fi

echo ""
echo -e "${YELLOW}⚠️  COPY THIS TOKEN TO KHAREJ SERVER:${NC}"
echo -e "${GREEN}$TOKEN${NC}"
echo ""
echo -e "${CYAN}📊 Dashboard: http://$PUBLIC_IP:7777${NC}"
echo -e "${CYAN}🔧 Manage: bomalo status | bomalo user-add${NC}"
