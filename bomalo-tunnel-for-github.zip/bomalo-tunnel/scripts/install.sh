#!/bin/bash
set -e

REPO="yourusername/bomalo-tunnel"
INSTALL_DIR="/usr/local/bin"
CONFIG_DIR="/etc/bomalo"
SERVICE_DIR="/etc/systemd/system"

echo "🌐 Bomalo Tunnel Installer"
echo "═══════════════════════════════════════════════════════"

ARCH=$(uname -m)
case $ARCH in
    x86_64)  BIN_ARCH="amd64" ;;
    aarch64) BIN_ARCH="arm64" ;;
    armv7l)  BIN_ARCH="arm"   ;;
    *)       echo "❌ Unsupported arch: $ARCH"; exit 1 ;;
esac

OS=$(uname -s | tr '[:upper:]' '[:lower:]')
if [[ "$OS" != "linux" ]]; then
    echo "⚠️  Bomalo Tunnel is optimized for Linux."
fi

echo "   Arch: $BIN_ARCH | OS: $OS"
echo ""

# === MANDATORY PRE-INSTALL TESTS ===
echo "🧪 Running mandatory pre-installation tests..."
echo "───────────────────────────────────────────────────────"

# Test 1: Google DNS
echo -n "   Testing Google DNS (8.8.8.8)... "
if timeout 5 bash -c "exec 3<>/dev/udp/8.8.8.8/53"; then
    echo "✅ PASS"
else
    echo "❌ FAIL"
    echo ""
    echo "🚫 Installation BLOCKED: Cannot reach Google DNS."
    echo "   Please check your internet connection and try again."
    exit 1
fi

# Test 2: Download capability
echo -n "   Testing GitHub connectivity... "
if curl -fsSL -I "https://github.com" > /dev/null 2>&1; then
    echo "✅ PASS"
else
    echo "❌ FAIL"
    echo ""
    echo "🚫 Installation BLOCKED: Cannot reach GitHub."
    exit 1
fi

# Test 3: Public IP detection
echo -n "   Detecting public IP... "
MY_IP=$(curl -fsSL --connect-timeout 10 https://api.ipify.org 2>/dev/null || echo "")
if [[ -n "$MY_IP" ]]; then
    echo "✅ PASS (IP: $MY_IP)"
else
    echo "⚠️  WARNING (Could not detect public IP)"
fi

echo "───────────────────────────────────────────────────────"
echo "✅ All mandatory tests passed! Proceeding with installation."
echo ""

# === DOWNLOAD & INSTALL ===
LATEST=$(curl -s "https://api.github.com/repos/$REPO/releases/latest" | grep '"tag_name":' | sed -E 's/.*"([^"]+)".*/\1/')
if [[ -z "$LATEST" ]]; then
    echo "⚠️  Could not detect latest release. Using 'dev'."
    LATEST="dev"
fi

echo "📦 Downloading $LATEST..."
URL="https://github.com/$REPO/releases/download/$LATEST/bomalo-$OS-$BIN_ARCH.tar.gz"
TMP=$(mktemp -d)

if ! curl -fsSL "$URL" -o "$TMP/bomalo.tar.gz" 2>/dev/null; then
    echo "❌ Download failed."
    echo ""
    echo "💡 Building from source..."
    if command -v go &> /dev/null; then
        git clone "https://github.com/$REPO.git" "$TMP/src"
        cd "$TMP/src"
        make build
        cp bin/bomalo "$TMP/"
        cp bin/bomalod "$TMP/"
    else
        echo "❌ Go not installed. Cannot build from source."
        rm -rf "$TMP"
        exit 1
    fi
else
    echo "📂 Extracting..."
    tar -xzf "$TMP/bomalo.tar.gz" -C "$TMP"
fi

echo "🔧 Installing binaries to $INSTALL_DIR..."
install -Dm755 "$TMP/bomalo" "$INSTALL_DIR/bomalo"
install -Dm755 "$TMP/bomalod" "$INSTALL_DIR/bomalod"

# Create config directory
mkdir -p "$CONFIG_DIR"
if [[ ! -f "$CONFIG_DIR/config.yaml" ]]; then
    cat > "$CONFIG_DIR/config.yaml" <<EOF
role: kharej
node_id: auto
token: CHANGE_ME
tunnel_port: 8443
transports:
  - tcp
  - quic
  - wireguard
auto_transport: true
grpc_addr: ":50051"
rest_addr: ":8080"
dashboard_addr: ":7777"
enable_ebpf: true
enable_mesh: false
EOF
    echo "📝 Default config created at $CONFIG_DIR/config.yaml"
fi

# Install systemd service
if command -v systemctl &> /dev/null; then
    cat > "$SERVICE_DIR/bomalo.service" <<EOF
[Unit]
Description=Bomalo Tunnel Daemon
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=$INSTALL_DIR/bomalod --config $CONFIG_DIR/config.yaml
Restart=always
RestartSec=5
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
    echo "✅ systemd service installed."
    echo "   Run: sudo systemctl enable --now bomalo"
fi

rm -rf "$TMP"

echo ""
echo "═══════════════════════════════════════════════════════"
echo "🎉 Bomalo Tunnel installed successfully!"
echo "═══════════════════════════════════════════════════════"
echo ""
echo "   CLI:    bomalo --help"
echo "   Daemon: bomalod --config $CONFIG_DIR/config.yaml"
echo "   Config: $CONFIG_DIR/config.yaml"
echo ""
echo "🚀 Quick start:"
echo "   1. Iran:   sudo bomalo setup --role iran --ports 443,8080"
echo "   2. Kharej: sudo bomalo setup --role kharej --iran-ip <IP>"
echo ""
echo "   Or run interactive menu: sudo bomalo"
echo ""
