#!/bin/bash
# Bomalo Tunnel - Kharej Server Rebuild Script
# This script completely rebuilds the Kharej (exit) server

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║${GREEN}        🌐  B O M A L O   T U N N E L  -  R E B U I L D       ${CYAN}║${NC}"
echo -e "${CYAN}║${YELLOW}                  Kharej Server (Exit Node)                     ${CYAN}║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check if Iran IP and token provided
if [ -z "$1" ] || [ -z "$2" ]; then
    echo -e "${YELLOW}Usage: $0 <IRAN_IP> <MASTER_TOKEN>${NC}"
    echo -e "${YELLOW}Example: $0 1.2.3.4 abcdef123...${NC}"
    echo ""
    echo -e "${CYAN}Enter Iran Server IP:${NC}"
    read IRAN_IP
    echo -e "${CYAN}Enter Master Token from Iran server:${NC}"
    read -s MASTER_TOKEN
    echo ""
else
    IRAN_IP=$1
    MASTER_TOKEN=$2
fi

# Validate inputs
if [ -z "$IRAN_IP" ] || [ -z "$MASTER_TOKEN" ]; then
    echo -e "${RED}❌ Iran IP and Master Token are required!${NC}"
    exit 1
fi

# === STEP 1: BACKUP ===
echo -e "${BLUE}[1/9] Creating backup before rebuild...${NC}"
BACKUP_DIR="/root/bomalo-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"
if [ -f /etc/bomalo/config.yaml ]; then
    cp /etc/bomalo/config.yaml "$BACKUP_DIR/"
    echo -e "${GREEN}✓ Config backed up${NC}"
fi

# === STEP 2: STOP SERVICES ===
echo -e "${BLUE}[2/9] Stopping services...${NC}"
systemctl stop bomalo 2>/dev/null || true
systemctl disable bomalo 2>/dev/null || true
pkill -f bomalo 2>/dev/null || true
pkill -f bomalod 2>/dev/null || true
echo -e "${GREEN}✓ Services stopped${NC}"

# === STEP 3: CLEANUP ===
echo -e "${BLUE}[3/9] Cleaning up...${NC}"
rm -rf /usr/local/bin/bomalo /usr/local/bin/bomalod
rm -rf /etc/bomalo /var/lib/bomalo
rm -f /etc/systemd/system/bomalo.service
systemctl daemon-reload
echo -e "${GREEN}✓ Cleaned up${NC}"

# === STEP 4: SYSTEM UPDATE ===
echo -e "${BLUE}[4/9] Updating system...${NC}"
apt-get update -qq
apt-get upgrade -y -qq
echo -e "${GREEN}✓ System updated${NC}"

# === STEP 5: INSTALL DEPENDENCIES ===
echo -e "${BLUE}[5/9] Installing dependencies...${NC}"
apt-get install -y -qq \
    curl wget git \
    iptables iproute2 \
    net-tools dnsutils \
    ca-certificates
echo -e "${GREEN}✓ Dependencies installed${NC}"

# === STEP 6: NETWORK OPTIMIZATION ===
echo -e "${BLUE}[6/9] Optimizing network...${NC}"
cat >> /etc/sysctl.conf << 'EOF'
net.ipv4.ip_forward=1
net.core.rmem_max=134217728
net.core.wmem_max=134217728
net.ipv4.tcp_rmem=4096 87380 134217728
net.ipv4.tcp_wmem=4096 65536 134217728
net.ipv4.tcp_congestion_control=bbr
fs.file-max=2097152
EOF
sysctl -p >/dev/null 2>&1
echo -e "${GREEN}✓ Network optimized${NC}"

# === STEP 7: TEST CONNECTIVITY TO IRAN ===
echo -e "${BLUE}[7/9] Testing connectivity to Iran ($IRAN_IP)...${NC}"
echo -e "${YELLOW}   Testing DNS (8.8.8.8)...${NC}"
if timeout 5 bash -c "exec 3<>/dev/udp/8.8.8.8/53"; then
    echo -e "${GREEN}   ✓ DNS OK${NC}"
else
    echo -e "${RED}   ✗ DNS failed${NC}"
fi

echo -e "${YELLOW}   Pinging Iran server...${NC}"
if ping -c 3 -W 5 "$IRAN_IP" >/dev/null 2>&1; then
    echo -e "${GREEN}   ✓ Iran server reachable${NC}"
else
    echo -e "${RED}   ✗ Cannot ping Iran server${NC}"
    echo -e "${YELLOW}   Continuing anyway...${NC}"
fi

echo -e "${YELLOW}   Testing TCP to Iran:8443...${NC}"
if timeout 5 bash -c "exec 3<>/dev/tcp/$IRAN_IP/8443" 2>/dev/null; then
    echo -e "${GREEN}   ✓ TCP port 8443 open${NC}"
else
    echo -e "${YELLOW}   ⚠ Port 8443 not responding (may need Iran server start first)${NC}"
fi

# === STEP 8: INSTALL BOMALO ===
echo -e "${BLUE}[8/9] Installing Bomalo...${NC}"

ARCH=$(uname -m)
case $ARCH in
    x86_64)  BIN_ARCH="amd64" ;;
    aarch64) BIN_ARCH="arm64" ;;
    *)       BIN_ARCH="amd64" ;;
esac

REPO="yourusername/bomalo-tunnel"
LATEST=$(curl -s "https://api.github.com/repos/$REPO/releases/latest" | grep '"tag_name":' | sed -E 's/.*"([^"]+)".*/\1/')
[ -z "$LATEST" ] && LATEST="v1.0.0"

cd /tmp
curl -fsSL "https://github.com/$REPO/releases/download/$LATEST/bomalo-linux-$BIN_ARCH.tar.gz" -o bomalo.tar.gz 2>/dev/null || {
    echo -e "${YELLOW}   Download failed, building from source...${NC}"
    apt-get install -y -qq golang-go
    git clone "https://github.com/$REPO.git" /tmp/bomalo-src
    cd /tmp/bomalo-src && make build
    cp bin/bomalo /usr/local/bin/ && cp bin/bomalod /usr/local/bin/
}

if [ -f bomalo.tar.gz ]; then
    tar -xzf bomalo.tar.gz
    install -Dm755 bomalo /usr/local/bin/bomalo
    install -Dm755 bomalod /usr/local/bin/bomalod
fi

echo -e "${GREEN}✓ Bomalo installed${NC}"

# === STEP 9: CONFIGURE ===
echo -e "${BLUE}[9/9] Configuring Kharej server...${NC}"

mkdir -p /etc/bomalo /var/lib/bomalo

PUBLIC_IP=$(curl -fsSL --connect-timeout 10 https://api.ipify.org 2>/dev/null || echo "YOUR_IP")

cat > /etc/bomalo/config.yaml << EOF
role: kharej
node_id: kharej-$(openssl rand -hex 4)
token: $MASTER_TOKEN
iran_addr: "$IRAN_IP"
tunnel_port: 8443
transports:
  - tcp
  - quic
  - webrtc
  - wireguard
  - kcp
  - openvpn
  - l2tp
auto_transport: true
grpc_addr: ":50051"
rest_addr: ":8080"
dashboard_addr: ":7777"
websocket_addr: ":7778"
data_dir: "/var/lib/bomalo"
log_level: info
enable_ebpf: false
enable_mesh: false
dpi:
  enabled: true
  mimic_profile: https
  jitter_enabled: true
  jitter_max_ms: 15
EOF

# Install systemd service
cat > /etc/systemd/system/bomalo.service << 'EOF'
[Unit]
Description=Bomalo Tunnel Daemon
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/bin/bomalod --config /etc/bomalo/config.yaml
Restart=always
RestartSec=5
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable bomalo

# === FINAL OUTPUT ===
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║${CYAN}             ✅ Kharej Server Rebuild Complete!                 ${GREEN}║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}📡 Kharej IP:${NC} $PUBLIC_IP"
echo -e "${YELLOW}🔗 Iran IP:${NC} $IRAN_IP"
echo -e "${YELLOW}🔑 Token:${NC} ${GREEN}${MASTER_TOKEN:0:16}...${NC}"
echo ""
echo -e "${CYAN}🚀 Starting Bomalo and connecting to Iran...${NC}"
systemctl start bomalo
sleep 3

if systemctl is-active --quiet bomalo; then
    echo -e "${GREEN}✅ Bomalo is running and connected!${NC}"
    echo ""
    echo -e "${CYAN}📊 Checking connection status...${NC}"
    sleep 2
    bomalo status 2>/dev/null || echo -e "${YELLOW}   Run 'bomalo status' to check${NC}"
else
    echo -e "${RED}❌ Failed to start. Check: journalctl -u bomalo -f${NC}"
fi

echo ""
echo -e "${CYAN}📊 Dashboard: http://$PUBLIC_IP:7777${NC}"
echo -e "${CYAN}🧪 Test: bomalo link-test${NC}"
