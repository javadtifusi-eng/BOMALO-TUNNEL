#!/bin/bash
# Bomalo Tunnel - Master Rebuild Script
# Rebuilds BOTH Iran and Kharej servers

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║${GREEN}     🌐  B O M A L O   T U N N E L  -  M A S T E R   R E B U I L D  ${CYAN}║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "${YELLOW}This script will rebuild BOTH servers:${NC}"
echo -e "  1. Iran Server (Entry Point)"
echo -e "  2. Kharej Server (Exit Node)"
echo ""
read -p "Are you sure? (yes/no): " confirm

if [ "$confirm" != "yes" ]; then
    echo -e "${RED}Aborted.${NC}"
    exit 1
fi

echo ""
echo -e "${CYAN}══════════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}Step 1: Rebuilding Iran Server${NC}"
echo -e "${CYAN}══════════════════════════════════════════════════════════════${NC}"

# Run Iran rebuild locally or via SSH
if [ -f "./rebuild-iran.sh" ]; then
    ./rebuild-iran.sh
else
    echo -e "${YELLOW}Please run rebuild-iran.sh on your Iran server first.${NC}"
    echo -e "${CYAN}wget -O - https://raw.githubusercontent.com/yourusername/bomalo-tunnel/main/scripts/rebuild-iran.sh | bash${NC}"
    exit 1
fi

echo ""
echo -e "${CYAN}══════════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}Step 2: Rebuilding Kharej Server${NC}"
echo -e "${CYAN}══════════════════════════════════════════════════════════════${NC}"

# Get token from Iran server config
TOKEN=$(grep "token:" /etc/bomalo/config.yaml 2>/dev/null | awk '{print $2}')
IRAN_IP=$(curl -fsSL https://api.ipify.org 2>/dev/null)

if [ -z "$TOKEN" ]; then
    echo -e "${RED}❌ Could not read token from Iran server!${NC}"
    echo -e "${YELLOW}Please enter manually:${NC}"
    read TOKEN
fi

echo -e "${YELLOW}Iran IP: $IRAN_IP${NC}"
echo -e "${YELLOW}Token: ${TOKEN:0:16}...${NC}"
echo ""

if [ -f "./rebuild-kharej.sh" ]; then
    ./rebuild-kharej.sh "$IRAN_IP" "$TOKEN"
else
    echo -e "${YELLOW}Please run on Kharej server:${NC}"
    echo -e "${CYAN}wget -O - https://raw.githubusercontent.com/yourusername/bomalo-tunnel/main/scripts/rebuild-kharej.sh | bash -s $IRAN_IP $TOKEN${NC}"
fi

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║${CYAN}           ✅ BOTH SERVERS REBUILT SUCCESSFULLY!                ${GREEN}║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}🎉 Bomalo Tunnel is ready for 1000+ users!${NC}"
