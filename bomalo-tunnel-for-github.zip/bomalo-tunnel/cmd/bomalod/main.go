package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"

	"github.com/yourusername/bomalo-tunnel/internal/api/grpc"
	"github.com/yourusername/bomalo-tunnel/internal/api/rest"
	"github.com/yourusername/bomalo-tunnel/internal/config"
	"github.com/yourusername/bomalo-tunnel/internal/dashboard"
	"github.com/yourusername/bomalo-tunnel/internal/tunnel"
)

var Version = "dev"

func main() {
	log.SetFlags(log.LstdFlags | log.Lshortfile)
	log.Printf("🚀 Bomalo Daemon v%s starting...", Version)

	cfg, err := config.Load("/etc/bomalo/config.yaml")
	if err != nil {
		log.Printf("⚠️  Using default config: %v", err)
		cfg = config.Default()
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	engine, err := tunnel.NewEngine(cfg)
	if err != nil {
		log.Fatalf("Failed to create tunnel engine: %v", err)
	}

	if err := engine.Start(ctx); err != nil {
		log.Fatalf("Failed to start engine: %v", err)
	}

	go func() {
		if err := grpc.Start(cfg.GRPCAddr, engine); err != nil {
			log.Printf("gRPC server error: %v", err)
		}
	}()

	go func() {
		if err := rest.Start(cfg.RESTAddr, engine); err != nil {
			log.Printf("REST server error: %v", err)
		}
	}()

	go func() {
		if err := dashboard.Start(cfg.DashboardAddr, engine); err != nil {
			log.Printf("Dashboard error: %v", err)
		}
	}()

	log.Printf("✅ Bomalo Daemon ready")
	log.Printf("   gRPC:      %s", cfg.GRPCAddr)
	log.Printf("   REST API:  %s", cfg.RESTAddr)
	log.Printf("   Dashboard: %s", cfg.DashboardAddr)

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	<-sigCh

	log.Println("🛑 Shutting down gracefully...")
	cancel()
	engine.Stop()
	log.Println("👋 Goodbye!")
}
