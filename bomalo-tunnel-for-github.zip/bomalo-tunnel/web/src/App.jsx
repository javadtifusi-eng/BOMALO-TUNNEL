import React, { useEffect, useState } from 'react';
import './App.css';

function App() {
  const [stats, setStats] = useState(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const ws = new WebSocket(`ws://${window.location.hostname}:7778/ws`);
    ws.onopen = () => setConnected(true);
    ws.onmessage = (event) => {
      setStats(JSON.parse(event.data));
    };
    ws.onclose = () => setConnected(false);
    return () => ws.close();
  }, []);

  return (
    <div className="dashboard">
      <header>
        <h1>🌐 Bomalo Tunnel</h1>
        <span className={`status ${connected ? 'online' : 'offline'}`}>
          {connected ? '● Live' : '● Disconnected'}
        </span>
      </header>

      <div className="cards">
        <div className="card">
          <h3>Node ID</h3>
          <p>{stats?.node_id || '—'}</p>
        </div>
        <div className="card">
          <h3>Role</h3>
          <p className="role">{stats?.role || '—'}</p>
        </div>
        <div className="card">
          <h3>Active Sessions</h3>
          <p className="metric">{stats?.active_sessions ?? 0}</p>
        </div>
        <div className="card">
          <h3>Transports</h3>
          <p className="metric">{stats?.active_transports ?? 0}</p>
        </div>
      </div>

      <div className="panel">
        <h2>🧠 AI Optimizer</h2>
        <p>Auto-transport: <strong>{stats?.auto_transport ? 'Enabled' : 'Disabled'}</strong></p>
        <p>Current best transport is selected automatically every 15s based on RTT, jitter, and loss.</p>
      </div>

      <div className="panel">
        <h2>📡 Transports</h2>
        <table>
          <thead>
            <tr><th>Transport</th><th>Status</th><th>Latency</th><th>Score</th></tr>
          </thead>
          <tbody>
            <tr><td>TCP</td><td className="ok">● Active</td><td>120ms</td><td>72</td></tr>
            <tr><td>QUIC</td><td className="ok">● Active</td><td>45ms</td><td>98</td></tr>
            <tr><td>WebRTC</td><td className="ok">● Active</td><td>52ms</td><td>91</td></tr>
            <tr><td>WireGuard</td><td className="ok">● Active</td><td>48ms</td><td>95</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default App;
