/* SPDX-License-Identifier: GPL-2.0 */
#include <linux/bpf.h>
#include <linux/if_ether.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_endian.h>

/* eBPF socket redirect program for Bomalo Tunnel */

struct {
    __uint(type, BPF_MAP_TYPE_SOCKHASH);
    __uint(max_entries, 65536);
    __type(key, __u64);
    __type(value, __u32);
} sock_hash SEC(".maps");

SEC("sk_msg")
int bomalo_redirect(struct sk_msg_md *msg)
{
    __u64 key = ((__u64)msg->remote_ip4 << 32) | msg->remote_port;
    bpf_msg_redirect_hash(msg, &sock_hash, &key, BPF_F_INGRESS);
    return SK_PASS;
}

SEC("sk_skb/stream_parser")
int bomalo_parser(struct __sk_buff *skb)
{
    return skb->len;
}

SEC("sk_skb/stream_verdict")
int bomalo_verdict(struct __sk_buff *skb)
{
    __u64 key = ((__u64)skb->remote_ip4 << 32) | skb->remote_port;
    return bpf_sk_redirect_hash(skb, &sock_hash, &key, 0);
}

char _license[] SEC("license") = "GPL";
