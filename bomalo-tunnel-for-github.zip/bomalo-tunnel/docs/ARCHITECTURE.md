# Bomalo Tunnel Architecture

## Overview

Bomalo Tunnel is a next-generation reverse tunnel engine designed for high-performance, adaptive, and stealthy edge-to-origin connectivity.

## Core Components

### 1. Tunnel Engine (`internal/tunnel/`)
The central orchestrator that manages sessions, port forwarding, and encryption. Uses the Noise Protocol for lightweight, modern cryptography.

### 2. Pluggable Transports (`internal/transport/`)
Each transport implements a common interface. New transports can be added without modifying core logic.

### 3. AI Optimizer (`internal/ai/`)
A real-time scoring engine that monitors RTT, jitter, and packet loss across all transports. Automatically switches to the healthiest transport.

### 4. eBPF Accelerator (`internal/ebpf/`)
Linux-specific kernel bypass using socket maps. Reduces latency by up to 40% on supported kernels.

### 5. Edge Mesh (`internal/mesh/`)
Multi-node topology for redundancy. Automatically load-balances across healthy Iran entry points.

### 6. DPI Evasion (`internal/dpi/`)
Adaptive traffic shaping, jitter injection, and protocol mimicry to defeat deep packet inspection.

## Data Flow

```
User Traffic → Iran Server → Bomalo Engine → Best Transport → Kharej Server → Origin Service
                    ↑                                              ↓
               AI Optimizer ←── Health Probes ───────────────────┘
```

## Security

- **Encryption**: ChaCha20-Poly1305 via Noise Protocol
- **Key Derivation**: Argon2id from shared token
- **Authentication**: Per-session tokens, PROXY protocol v2 support
- **Integrity**: SHA-256 verified releases
